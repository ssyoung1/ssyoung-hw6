# HW6 Starter (Git Practice)

This folder contains starter files for your Git/GitHub homework.

**Suggested commit flow (GitHub Desktop):**
1. Create repo with README (first commit).
2. Add `index.html` (commit message: "Add index.html hello world").
3. Create feature branch `css_formatting`.
4. Add `css/stylesheet.css` and link it in `index.html` (commit: "Add base stylesheet and link").
5. Tweak styles/content (commit: "Add centered content styles").
6. Add your name/favorite color text (commit: "Add name and favorite color").
7. Merge `css_formatting` back into `main`, then tag `HW6`.

Replace `hawkid` with your real HawkID when you create your repository.
